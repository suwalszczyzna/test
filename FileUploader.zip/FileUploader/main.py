import tkinter as tk

from file_uploader_app import FileUploaderApp

if __name__ == "__main__":
    root = tk.Tk()
    app = FileUploaderApp(root)
    root.mainloop()
